import os

import requests
from dotenv import load_dotenv

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
DEFAULT_MODEL = "llama-3.1-8b-instant"

load_dotenv(".env")


def ask_ai(message, context=None):
    api_key = (os.getenv("GROQ_API_KEY") or "").strip()
    if not api_key:
        return None

    payload = {
        "model": os.getenv("GROQ_MODEL", DEFAULT_MODEL),
        "messages": build_messages(message, context or []),
        "temperature": 0.72,
        "max_tokens": 650,
    }

    try:
        response = requests.post(
            GROQ_URL,
            json=payload,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=25,
        )
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"].strip()
    except (requests.RequestException, KeyError, IndexError, TypeError, ValueError):
        return None


def build_messages(message, context):
    messages = [
        {
            "role": "system",
            "content": (
                "Voce e o Orion, um assistente IA simples, moderno e util. "
                "Responda em portugues do Brasil, com clareza e objetividade. "
                "Use o historico apenas quando ajudar."
            ),
        }
    ]

    for item in context:
        role = item.get("role")
        content = item.get("content")
        if role in {"user", "assistant"} and content:
            messages.append({"role": role, "content": content})

    messages.append({"role": "user", "content": message})
    return messages
